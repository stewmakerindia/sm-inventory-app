import React from "react";

const procurementList = [
  { item: "Chicken", unit: "kg", total: 0 },
  { item: "Mutton", unit: "kg", total: 0 },
  { item: "Eggs", unit: "tray", total: 0 },
  { item: "Prawns", unit: "kg", total: 0 },
  { item: "Coconut", unit: "pc", total: 0 },
  { item: "Potato", unit: "kg", total: 0 },
  { item: "Beans", unit: "kg", total: 0 },
  { item: "Onion", unit: "kg", total: 0 },
  { item: "Small Onion", unit: "kg", total: 0 },
  { item: "Carrot", unit: "kg", total: 0 },
  { item: "Ginger", unit: "kg", total: 0 },
  { item: "Raw Mango", unit: "kg", total: 0 },
  { item: "Peeled Garlic", unit: "kg", total: 0 },
  { item: "Vinegar", unit: "ltr", total: 0 },
  { item: "Bread", unit: "kg", total: 0 },
  { item: "Bread Powder", unit: "kg", total: 0 },
  { item: "Instant Dry Yeast", unit: "packet", total: 0 },
  { item: "Maida", unit: "kg", total: 0 },
  { item: "Mushroom", unit: "packet", total: 0 },
  { item: "Chips", unit: "packet", total: 0 },
  { item: "Pickles", unit: "kg", total: 0 },
  { item: "Coconut Powder", unit: "packet", total: 0 },
  { item: "Magic Masala", unit: "packet", total: 0 },
  { item: "Soya Granules", unit: "packet", total: 0 },
  { item: "Eastern Chilli Powder", unit: "packet", total: 0 },
  { item: "Eastern Turmeric Powder", unit: "packet", total: 0 },
  { item: "Garam Masala", unit: "packet", total: 0 },
  { item: "Salt", unit: "kg", total: 0 },
  { item: "Sugar", unit: "kg", total: 0 },
  { item: "Cloves", unit: "kg", total: 0 },
  { item: "Cardamom", unit: "packet", total: 0 },
  { item: "Black Pepper", unit: "kg", total: 0 },
  { item: "Cinnamon", unit: "kg", total: 0 },
  { item: "Dry Chilli", unit: "kg", total: 0 },
  { item: "Dry Chilli Round", unit: "kg", total: 0 },
  { item: "Whole Coriander", unit: "kg", total: 0 },
  { item: "Fennel", unit: "kg", total: 0 },
  { item: "Raisins", unit: "kg", total: 0 },
  { item: "Cashew (4 pcs)", unit: "kg", total: 0 },
  { item: "Sunflower Oil", unit: "ltr", total: 0 },
  { item: "Ghee (Amul)", unit: "ltr", total: 0 },
  { item: "Coconut Oil (KPL)", unit: "ltr", total: 0 },
  { item: "Appam Rice", unit: "kg", total: 0 },
  { item: "Ghee Rice", unit: "kg", total: 0 },
  { item: "Banana Leaf", unit: "pc", total: 0 },
  { item: "Appam Box", unit: "pc", total: 0 },
  { item: "SM Bag", unit: "pc", total: 0 },
  { item: "SM Bag (w/o handle)", unit: "pc", total: 0 },
  { item: "Railway Meal Cover", unit: "rim", total: 0 },
  { item: "Cutlet Box", unit: "pc", total: 0 },
  { item: "700ml Container", unit: "pc", total: 0 },
  { item: "450ml Container", unit: "pc", total: 0 },
  { item: "Chutney Box", unit: "packet", total: 0 },
  { item: "Silver Pouch - 9X12", unit: "pc", total: 0 },
  { item: "Silver Pouch - 6X9", unit: "pc", total: 0 },
  { item: "Tape", unit: "pack of 12", total: 0 },
  { item: "Printer Rolls", unit: "pack of 10", total: 0 },
  { item: "Garbage Bag - 24 X 32", unit: "pc", total: 0 },
];

export default function ProcurementSummary() {
  const today = new Date();
  const formattedDate = today.toLocaleDateString("en-IN", {
    weekday: "long",
    day: "2-digit",
    month: "short",
    year: "numeric",
  });

  const shareOnWhatsApp = () => {
    const phoneNumber = "916364370503"; // Updated HQ number
    const message = `*Procurement Summary - ${formattedDate}*

` +
      procurementList
        .filter(({ total }) => total > 0)
        .map(({ item, unit, total }) => `• ${item}: ${total} ${unit}`)
        .join("\n") || "No items to procure.";

    const encodedMessage = encodeURIComponent(message);
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${encodedMessage}`;
    window.open(whatsappURL, "_blank");
  };

  return (
    <div className="pb-20">
      <h2 className="text-lg font-semibold mb-2">Procurement Summary</h2>
      <p className="mb-4 text-sm text-gray-600">{formattedDate}</p>
      <div className="bg-white shadow rounded-md overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-100">
            <tr>
              <th className="px-4 py-2">Item</th>
              <th className="px-4 py-2">Unit</th>
              <th className="px-4 py-2">Total Qty</th>
            </tr>
          </thead>
          <tbody>
            {procurementList.map(({ item, unit, total }) => (
              <tr key={item} className="border-t">
                <td className="px-4 py-2">{item}</td>
                <td className="px-4 py-2">{unit}</td>
                <td className="px-4 py-2 font-medium">{total}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="mt-4 text-right">
        <button
          className="bg-green-500 hover:bg-green-600 text-white font-medium py-2 px-4 rounded"
          onClick={shareOnWhatsApp}
        >
          Share on WhatsApp
        </button>
      </div>
    </div>
  );
}