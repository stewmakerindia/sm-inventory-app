
import React from "react";
import ProcurementSummary from "./ProcurementSummary";

function App() {
  return (
    <div className="p-4">
      <ProcurementSummary />
    </div>
  );
}

export default App;
